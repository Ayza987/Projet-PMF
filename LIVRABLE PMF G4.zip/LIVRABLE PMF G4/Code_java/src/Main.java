import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ArduinoApp app = new ArduinoApp();
            app.valuesInstance = new Values(); // Initialiser valuesInstance ici
            app.valuesInstance.setVisible(true);
            app.setVisible(true);


        });
    }
}