import javax.swing.*;
import com.fazecast.jSerialComm.SerialPort;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class ArduinoApp extends JFrame {
    private List<Float> humidityValues = new ArrayList<>();
    private List<Float> temperatureintvalues = new ArrayList<>();
    private List<Float> temperatureextValues = new ArrayList<>();
    private List<Float> pointValues = new ArrayList<>();
    private JComboBox<String> portComboBox;
    private JButton refreshButton;
    Values valuesInstance;
    private JButton connectButton;
    private JTextField temperatureField;
    private JLabel sentValueLabel;
    private SerialPort selectedPort;
    private JLabel humidityLabel;
    private JLabel indoorTemperatureLabel;
    private JLabel outdoorTemperatureLabel;
    private JLabel dewPointLabel;
    //private GraphFrame graphFrame;

    public ArduinoApp() {
        setTitle("Application pour la gestion d'un Mini-frigo");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel selectPortPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel selectPortLabel = new JLabel("Select a port:");
        selectPortPanel.add(selectPortLabel);
        portComboBox = new JComboBox<>();
        portComboBox.setPreferredSize(new Dimension(400, 25));
        selectPortPanel.add(portComboBox);
        refreshButton = new JButton("Actualiser");
        selectPortPanel.add(refreshButton);
        connectButton = new JButton("Connecter");
        selectPortPanel.add(connectButton);
        temperatureField = new JTextField();
        temperatureField.setPreferredSize(new Dimension(300, 100));
        selectPortPanel.add(temperatureField);
        sentValueLabel = new JLabel("Value Sent: ");
        sentValueLabel.setFont(new Font("SansSerif", Font.PLAIN, 20));
        mainPanel.add(sentValueLabel, BorderLayout.SOUTH);
        add(mainPanel, BorderLayout.CENTER);
        selectPortPanel.add(sentValueLabel);
        mainPanel.add(selectPortPanel, BorderLayout.NORTH);

        refreshButton.addActionListener(e -> refreshPortList());

        connectButton.addActionListener(e -> connectToArduino());

        SerialReader serialReader = new SerialReader();
        Thread readerThread = new Thread(serialReader);
        readerThread.start();
        humidityLabel = new JLabel("Humidité intérieure: ");
        indoorTemperatureLabel = new JLabel("Température intérieure: ");
        outdoorTemperatureLabel = new JLabel("Température extérieure: ");
        dewPointLabel = new JLabel("Point de rosée: ");

        JPanel dataPanel = new JPanel(new GridLayout(4, 2));
        dataPanel.add(humidityLabel);
        dataPanel.add(indoorTemperatureLabel);
        dataPanel.add(outdoorTemperatureLabel);
        dataPanel.add(dewPointLabel);


        mainPanel.add(dataPanel, BorderLayout.CENTER);
    }

    private void refreshPortList() {
        portComboBox.removeAllItems();
        SerialPort[] ports = SerialPort.getCommPorts();
        for (SerialPort port : ports) {
            portComboBox.addItem(port.getSystemPortName());
        }
    }

    private void connectToArduino() {
        String selectedPortName = (String) portComboBox.getSelectedItem();
        selectedPort = SerialPort.getCommPort(selectedPortName);

        if (!temperatureField.getText().isEmpty()) {
            try {
                double temperatureValue = Double.parseDouble(temperatureField.getText());

                selectedPort.setComPortParameters(9600, 8, 1, 0);
                selectedPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 0, 0);

                if (selectedPort.openPort()) {
                    JOptionPane.showMessageDialog(this, "Connexion établie avec succès!", "Succès", JOptionPane.INFORMATION_MESSAGE);

                    try (OutputStream outputStream = selectedPort.getOutputStream()) {
                        outputStream.write((int) temperatureValue);
                        outputStream.flush();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Impossible de se connecter au port série.", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Veuillez entrer une valeur numérique valide pour la température.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez entrer une valeur pour la température.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        if (selectedPort.openPort()) {
            JOptionPane.showMessageDialog(this, "Connexion établie avec succès!", "Succès", JOptionPane.INFORMATION_MESSAGE);
            SerialReader serialReader = new SerialReader();
            new Thread(serialReader).start();
        } else {
            JOptionPane.showMessageDialog(this, "Impossible de se connecter au port série.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        setVisible(true);
    }
    private class SerialReader implements Runnable {
        @Override
        public void run() {
            if (selectedPort == null) {
                System.out.println("Le port sélectionné n'est pas initialisé.");
                return;
            }

            try (InputStream inputStream = selectedPort.getInputStream();
                 Scanner scanner = new Scanner(inputStream)) {

                while (scanner.hasNextLine()) {
                    String receivedData = scanner.nextLine();
                    SwingUtilities.invokeLater(() -> processArduinoData(receivedData));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private void processArduinoData(String data) {
        String[] values = data.split(",");
        float humidityValue = 0;
        float temperatureint=0;
        float teemperatureext = 0;
        float point=0;
        if (values.length >= 2) {
            try {
                humidityValue = Float.parseFloat(values[0]);
                temperatureint = Float.parseFloat(values[1]);
                teemperatureext = Float.parseFloat(values[2]);
                point = Float.parseFloat(values[3]);

                humidityValues.add(humidityValue);
                System.out.println(humidityValues);
                temperatureintvalues.add(temperatureint);
                System.out.println(temperatureintvalues);
                temperatureextValues.add(teemperatureext);
                System.out.println(temperatureextValues);
                pointValues.add(point);
                System.out.println(pointValues);

                valuesInstance.updateHumidityLabel(String.valueOf(humidityValue));
                valuesInstance.updateIndoorTemperatureLabel(String.valueOf(temperatureint));
                valuesInstance.updateOutdoorTemperatureLabel(String.valueOf(teemperatureext));
                valuesInstance.updateDewPointLabel(String.valueOf(point));

            } catch (NumberFormatException e) {
                System.err.println("Erreur de conversion de la valeur : " + data);
            }
        }
        // valuesInstance.updateHumidityLabel(String.valueOf(humidityValue));
        // valuesInstance.updateIndoorTemperatureLabel(String.valueOf(temperatureint));
        //valuesInstance.updateOutdoorTemperatureLabel(String.valueOf(teemperatureext));
        //valuesInstance.updateDewPointLabel(String.valueOf(point));
        valuesInstance.updateChartData(humidityValue, temperatureint, teemperatureext, point);
        // ...
    }}