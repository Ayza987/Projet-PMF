package Controller;
import  Model.ArduinoApp;
import View.Values;

import javax.swing.*;

import Model.ArduinoApp;

public class Controller {

    public void initializeAndShowApp() {
        SwingUtilities.invokeLater(() -> {
            ArduinoApp app = new ArduinoApp();
            app.valuesInstance = new Values(); // Initialiser valuesInstance ici
            app.valuesInstance.setVisible(true);
            app.setVisible(true);
        });
    }}

